export class InventoryPage {
  constructor(page) {
    this.page = page;
    this.firstAddToCartButton = '.inventory_item button';
    this.cartIcon = '.shopping_cart_link';
  }

  async addFirstProductToCart() {
    await this.page.locator(this.firstAddToCartButton).first().click();
  }

  async goToCart() {
    await this.page.click(this.cartIcon);
  }
}