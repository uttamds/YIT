import { test, expect } from '@playwright/test';

test.describe('SauceDemo - Working with Collections', () => {

  test.beforeEach(async ({ page }) => {
    await page.goto('https://www.saucedemo.com/');
    await page.fill('#user-name', 'standard_user');
    await page.fill('#password', 'secret_sauce');
    await page.click('#login-button');
    await expect(page).toHaveURL(/inventory/);
  });

  test.afterEach(async ({ page }) => {
    await page.click('#react-burger-menu-btn');
    await page.click('#logout_sidebar_link');
    await expect(page).toHaveURL('https://www.saucedemo.com/');
  });

  // 🧪 Test 1: Count total products
  test('Verify total number of products displayed', async ({ page }) => {
    const products = page.locator('.inventory_item');
    await expect(products).toHaveCount(6);
  });

  // 🧪 Test 2: Click a product by index
  test('Open the second product from the list', async ({ page }) => {
    const productNames = page.locator('.inventory_item_name');

    const secondProduct = productNames.nth(1); // index starts from 0
    const name = await secondProduct.textContent();

    await secondProduct.click();
    await expect(page.locator('.inventory_details_name')).toHaveText(name);
  });

  // 🧪 Test 3: Add all products to cart using loop
  test('Add all products to cart', async ({ page }) => {
    const addToCartButtons = page.locator('button:has-text("Add to cart")');
    const count = await addToCartButtons.count();

    for (let i = 0; i < count; i++) {
      await addToCartButtons.nth(i).click();
    }

    await expect(page.locator('.shopping_cart_badge')).toHaveText(count.toString());
  });

  // 🧪 Test 4: Find and add a specific product by name
  test('Add "Sauce Labs Backpack" to cart using text filter', async ({ page }) => {
    const product = page.locator('.inventory_item').filter({
      hasText: 'Sauce Labs Backpack'
    });

    await product.locator('button').click();
    await page.click('.shopping_cart_link');

    await expect(page.locator('.inventory_item_name')).toHaveText('Sauce Labs Backpack');
  });

});
