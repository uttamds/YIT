const { test, expect } = require('@playwright/test');

test('verify input value 1234 with visible pauses', async ({ page }) => {

  await page.goto('http://127.0.0.1:5500/uttam.html');
  await page.goto('https://practicetestautomation.com/practice-test-login/');
  

  await page.waitForTimeout(3000);

  await page.fill('#codeInput', '1234');
  await page.waitForTimeout(3000);

  await page.selectOption('#cart', 'TV');
  await page.waitForTimeout(3000);

  

  await page.click('#checkBtn');
  await page.waitForTimeout(3000);

  // ✅ Wait first, then assert
  await page.waitForTimeout(3000);
  const resultText = await page.textContent('#result');

  expect(resultText).toBe('SUCCESS');
});
