for i in range(10):
    for j in range(5):
        print(f"i: {i}, j: {j}")    

        