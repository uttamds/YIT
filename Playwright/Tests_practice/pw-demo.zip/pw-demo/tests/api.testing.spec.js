import { test, expect } from '@playwright/test';
import usersData from './users.json';

const userIds = usersData.userIds;

for (const id of userIds) {

  test(`Get user ${id} from DummyJSON`, async ({ request }) => {

    const response = await request.get(`https://dummyjson.com/users/${id}`);
    expect(response.status()).toBe(200);

    const body = await response.json();
    expect(body.id).toBe(id);
    expect(body.firstName).toBeDefined();

  });

}

