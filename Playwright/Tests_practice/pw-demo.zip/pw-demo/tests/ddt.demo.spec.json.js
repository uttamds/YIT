import { test, expect } from '@playwright/test';
import loginData from './loginData.json';

test.describe('Data Driven Login Tests (JSON)', () => {

  for (const data of loginData) {

    test(`Login test for ${data.user}`, async ({ page }) => {

      await page.goto('http://127.0.0.1:5500/DDT/login.html');

      await page.fill('#username', data.user);
      await page.fill('#password', data.pass);
      await page.click('button');

      await expect(page.locator('#result')).toHaveText(data.expected);

    });

  }

});
