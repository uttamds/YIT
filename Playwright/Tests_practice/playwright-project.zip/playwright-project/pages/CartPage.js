export class CartPage {
  constructor(page) {
    this.page = page;
    this.cartItem = '.cart_item';
    this.checkoutButton = '#checkout';
  }

  async verifyItemInCart() {
    await this.page.waitForSelector(this.cartItem);
  }

  async proceedToCheckout() {
    await this.page.click(this.checkoutButton);
  }
}