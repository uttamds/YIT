import { test, expect } from '@playwright/test';
import { LoginPage } from '../pages/LoginPage';
import { InventoryPage } from '../pages/InventoryPage';
import { CartPage } from '../pages/CartPage';
import { CheckoutPage } from '../pages/CheckoutPage';

test('Complete product purchase flow', async ({ page }) => {

  const loginPage = new LoginPage(page);
  const inventoryPage = new InventoryPage(page);
  const cartPage = new CartPage(page);
  const checkoutPage = new CheckoutPage(page);

  // Step 1: Login
  await loginPage.goto();
  await loginPage.login('standard_user', 'secret_sauce');

  // Step 2: Add product to cart
  await inventoryPage.addFirstProductToCart();

  // Step 3: Go to cart
  await inventoryPage.goToCart();
  await cartPage.verifyItemInCart();

  // Step 4: Checkout
  await cartPage.proceedToCheckout();
  await checkoutPage.fillDetails('Rahul', 'Sharma', '400001');

  // Step 5: Finish order
  await checkoutPage.finishOrder();

  // Step 6: Verify success
  await checkoutPage.verifyOrderSuccess();
  await expect(page.locator('.complete-header')).toHaveText('Thank you for your order!');
});