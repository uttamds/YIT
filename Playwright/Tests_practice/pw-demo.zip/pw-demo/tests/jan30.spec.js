import { test, expect } from '@playwright/test';

test('Full User Actions + Assertions Demo', async ({ page }) => {

  // Load local file
  await page.goto('http://127.0.0.1:5500/jan30.html');

  // ---------------------------
  // 🔹 BASIC PAGE ASSERTIONS
  // ---------------------------
  await expect(page).toHaveTitle('Playwright Full Demo Page');
  await expect(page).toHaveURL(/jan30.html/);
  await expect(page.locator('#main-heading')).toHaveText('Playwright Demo');

  // ---------------------------
  // 🔹 INPUT ACTIONS
  // ---------------------------
  const nameInput = page.locator('#nameInput');

  await nameInput.fill('Rahul');
  await expect(nameInput).toHaveValue('Rahul');

  await nameInput.press('Control+A');   // Keyboard action
  await nameInput.press('Backspace');
  await expect(nameInput).toHaveValue('');

  await nameInput.type('Anita');
  await expect(nameInput).toHaveValue('Anita');

  await page.click('#clearBtn');
  await expect(nameInput).toBeEmpty();

  // ---------------------------
  // 🔹 DROPDOWN
  // ---------------------------
  await page.selectOption('#countrySelect', 'india');
  await expect(page.locator('#countrySelect')).toHaveValue('india');

  // ---------------------------
  // 🔹 CHECKBOX
  // ---------------------------
  const checkbox = page.locator('#subscribeCheck');
  await checkbox.check();
  await expect(checkbox).toBeChecked();

  await checkbox.uncheck();
  await expect(checkbox).not.toBeChecked();

  // ---------------------------
  // 🔹 RADIO BUTTON
  // ---------------------------
  await page.locator('input[value="female"]').check();
  await expect(page.locator('input[value="female"]')).toBeChecked();

  // ---------------------------
  // 🔹 BUTTON CLICK + TEXT VALIDATION
  // ---------------------------
  await page.click('#actionBtn');
  const message = page.locator('#message');
  await expect(message).toBeVisible();
  await expect(message).toHaveText('Button Clicked Successfully!');

  // ---------------------------
  // 🔹 ENABLED / DISABLED
  // ---------------------------
  const disabledBtn = page.locator('#disabledBtn');
  await expect(disabledBtn).toBeDisabled();
  await expect(page.locator('#actionBtn')).toBeEnabled();

  // ---------------------------
  // 🔹 ATTRIBUTE CHECK
  // ---------------------------
  await expect(nameInput).toHaveAttribute('placeholder', 'Enter name');

  // ---------------------------
  // 🔹 MOUSE ACTION (HOVER)
  // ---------------------------
  const hoverBox = page.locator('#hoverBox');
  await hoverBox.hover();

  // Validate CSS change after hover
  await expect(hoverBox).toHaveCSS('background-color', 'rgb(255, 165, 0)');
});
