import { test, expect } from '@playwright/test';

const testData = [
  { user: 'rahul',  pass: '1234', expected: 'Login Successful' },
  { user: 'anita',  pass: 'pass', expected: 'Login Successful' },
  { user: 'vikram', pass: 'wrong', expected: 'Login Failed' }
];



test.describe('Data Driven Login Tests', () => {

  for (const data of testData) {

    test(`Login test for ${data.user}`, async ({ page }) => {

      await page.goto('http://127.0.0.1:5500/DDT/login.html');

      await page.fill('#username', data.user);
      await page.fill('#password', data.pass);
      await page.click('button');

      await expect(page.locator('#result')).toHaveText(data.expected);

    });

  }

});
